$(".fondo").hover(function () {
    $(".fondo").css("background", "blue");
}, function () {
    $(".fondo").css("background", "bg-dark");
});

$(".empresas p").hover(function () {
    $(this).css("background-color", "yellow");
}, function () {
    $(this).css("background-color", "white");
});

$(".emp1").hover(function () {
    $(".emp1").css("font-size", "30px");
}, function () {
    $(".emp1").css("font-size", "25px");
});

$(".emp2").hover(function () {
    $(".emp2").css("font-size", "30px");
}, function () {
    $(".emp2").css("font-size", "25px");
});

$(".emp3").hover(function () {
    $(".emp3").css("font-size", "30px");
}, function () {
    $(".emp3").css("font-size", "25px");
});

$(".emp4").hover(function () {
    $(".emp4").css("font-size", "30px");
}, function () {
    $(".emp4").css("font-size", "25px");
});

$(".emp5").hover(function () {
    $(".emp5").css("font-size", "30px");
}, function () {
    $(".emp5").css("font-size", "25px");
});

$(".emp6").hover(function () {
    $(".emp6").css("font-size", "30px");
}, function () {
    $(".emp6").css("font-size", "25px");
});

$(".emp7").hover(function () {
    $(".emp7").css("font-size", "30px");
}, function () {
    $(".emp7").css("font-size", "25px");
});

$(".emp8").hover(function () {
    $(".emp8").css("font-size", "30px");
}, function () {
    $(".emp8").css("font-size", "25px");
});

$(".emp9").hover(function () {
    $(".emp9").css("font-size", "30px");
}, function () {
    $(".emp9").css("font-size", "25px");
});

$(".emp10").hover(function () {
    $(".emp10").css("font-size", "30px");
}, function () {
    $(".emp10").css("font-size", "25px");
});

$(".emp1").dblclick(function() {
    $(".emp1").css("color", "#21ACC2");
})

$(".emp1").click(function(){
    $(".emp1").css("color", "black");
});

$(".emp2").dblclick(function() {
    $(".emp2").css("color", "#21ACC2");
})

$(".emp2").click(function(){
    $(".emp2").css("color", "black");
});

$(".emp3").dblclick(function() {
    $(".emp3").css("color", "#21ACC2");
})

$(".emp3").click(function(){
    $(".emp3").css("color", "black");
});

$(".emp4").dblclick(function() {
    $(".emp4").css("color", "#21ACC2");
})

$(".emp4").click(function(){
    $(".emp4").css("color", "black");
});

$(".emp5").dblclick(function() {
    $(".emp5").css("color", "#21ACC2");
})

$(".emp5").click(function(){
    $(".emp5").css("color", "black");
});

$(".emp6").dblclick(function() {
    $(".emp6").css("color", "#21ACC2");
})

$(".emp6").click(function(){
    $(".emp6").css("color", "black");
});

$(".emp7").dblclick(function() {
    $(".emp7").css("color", "#21ACC2");
})

$(".emp7").click(function(){
    $(".emp7").css("color", "black");
});

$(".emp8").dblclick(function() {
    $(".emp8").css("color", "#21ACC2");
})

$(".emp8").click(function(){
    $(".emp8").css("color", "black");
});

$(".emp9").dblclick(function() {
    $(".emp9").css("color", "#21ACC2");
})

$(".emp9").click(function(){
    $(".emp9").css("color", "black");
});

$(".emp10").dblclick(function() {
    $(".emp10").css("color", "#21ACC2");
})

$(".emp10").click(function(){
    $(".emp10").css("color", "black");
});

